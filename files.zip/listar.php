<?php
/**
 * API para Listar Voluntários
 * GET: /listar.php
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once 'config.php';

try {
    $sql = "SELECT id, nome, cpf, data_nascimento, zona, secao, municipio, criado_em 
            FROM voluntarios 
            ORDER BY criado_em DESC";
    
    $result = $conexao->query($sql);
    
    if (!$result) {
        throw new Exception("Erro na query: " . $conexao->error);
    }
    
    $voluntarios = [];
    while ($row = $result->fetch_assoc()) {
        $voluntarios[] = $row;
    }
    
    echo json_encode([
        'sucesso' => true,
        'total' => count($voluntarios),
        'dados' => $voluntarios
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro ao listar voluntários: ' . $e->getMessage()
    ]);
}

$conexao->close();
?>
