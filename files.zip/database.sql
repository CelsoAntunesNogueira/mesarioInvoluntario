-- ============================================
-- Banco de Dados: gerador_mesario
-- ============================================

CREATE DATABASE IF NOT EXISTS gerador_mesario;
USE gerador_mesario;

-- ============================================
-- Tabela: voluntarios
-- ============================================
CREATE TABLE IF NOT EXISTS voluntarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  cpf VARCHAR(14) NOT NULL UNIQUE,
  data_nascimento DATE NOT NULL,
  zona INT NOT NULL,
  secao INT NOT NULL,
  municipio VARCHAR(100) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_cpf (cpf),
  INDEX idx_zona_secao (zona, secao)
);

-- ============================================
-- Registros de exemplo
-- ============================================
INSERT INTO voluntarios (nome, cpf, data_nascimento, zona, secao, municipio)
VALUES 
  ('João Silva Santos', '123.456.789-10', '1985-05-15', 1, 1001, 'Maricá - RJ'),
  ('Maria Oliveira Costa', '987.654.321-99', '1990-08-22', 2, 1002, 'Maricá - RJ');

-- ============================================
-- Descrição da tabela
-- ============================================
-- DESCRIBE voluntarios;
