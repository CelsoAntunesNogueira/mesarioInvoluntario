# ✅ CHECKLIST DE INSTALAÇÃO - Gerador de Mesário

## 📋 FASE 1: PREPARAÇÃO DO AMBIENTE

### Windows (XAMPP)
- [ ] Baixar XAMPP de https://www.apachefriends.org/
- [ ] Instalar XAMPP em `C:\xampp\`
- [ ] Abrir XAMPP Control Panel
- [ ] Iniciar Apache (Start)
- [ ] Iniciar MySQL (Start)
- [ ] Verificar se ambos estão rodando (deve aparecer "Running")

### Linux
```bash
- [ ] sudo apt-get update
- [ ] sudo apt-get install apache2
- [ ] sudo apt-get install mysql-server
- [ ] sudo apt-get install php php-mysql php-mysqli
- [ ] sudo systemctl start apache2
- [ ] sudo systemctl start mysql
```

### Mac (MAMP)
- [ ] Baixar MAMP de https://www.mamp.info/
- [ ] Instalar MAMP
- [ ] Abrir MAMP e clicar em "Start Servers"

---

## 📁 FASE 2: ESTRUTURA DE ARQUIVOS

### Copiar Arquivos para Servidor Web

**Windows (XAMPP):**
```
C:\xampp\htdocs\gerador-mesario\
  ├── index.html
  ├── style.css
  ├── script.js
  ├── config.php
  ├── salvar.php
  ├── listar.php
  ├── teste_conexao.php
  └── testes.html
```

**Linux (Apache):**
```
/var/www/html/gerador-mesario/
  ├── index.html
  ├── style.css
  ├── script.js
  ├── config.php
  ├── salvar.php
  ├── listar.php
  ├── teste_conexao.php
  └── testes.html
```

**Mac (MAMP):**
```
/Applications/MAMP/htdocs/gerador-mesario/
  ├── index.html
  ├── style.css
  ├── script.js
  ├── config.php
  ├── salvar.php
  ├── listar.php
  ├── teste_conexao.php
  └── testes.html
```

---

## 🗄️ FASE 3: CONFIGURAR BANCO DE DADOS

### Abrir MySQL Client

**Windows:**
- [ ] Abrir Command Prompt (cmd)
- [ ] Digitar: `mysql -u root -p`
- [ ] Pressionar Enter (sem senha se for padrão)

**Linux/Mac:**
- [ ] Abrir Terminal
- [ ] Digitar: `sudo mysql -u root`
- [ ] Ou: `mysql -u root -p`

### Executar Script SQL

- [ ] Copiar todo o conteúdo de `database.sql`
- [ ] Colar no MySQL Client
- [ ] Pressionar Enter
- [ ] Procurar por mensagens de sucesso

### Verificar Criação

```sql
- [ ] USE gerador_mesario;
- [ ] SHOW TABLES;
- [ ] DESCRIBE voluntarios;
- [ ] SELECT * FROM voluntarios;
```

Resultado esperado:
```
2 registros de exemplo devem aparecer
```

---

## 🔗 FASE 4: TESTAR CONEXÃO

### Teste 1: Via Navegador

- [ ] Abrir navegador (Chrome, Firefox, Edge, etc)
- [ ] Acessar: `http://localhost/gerador-mesario/teste_conexao.php`
- [ ] Procurar pela mensagem: **"✅ Tudo OK!"**

Resultado esperado:
```json
{
  "status": "sucesso",
  "resumo": "✅ Tudo OK! Banco de dados pronto para usar",
  "testes": [...]
}
```

### Teste 2: Página de Testes Interativa

- [ ] Acessar: `http://localhost/gerador-mesario/testes.html`
- [ ] Clicar em "Testar Conexão" (primeira seção)
- [ ] Clicar em "Salvar Voluntário" (segunda seção)
- [ ] Clicar em "Listar Voluntários" (terceira seção)

Resultado esperado:
- Todos os testes devem mostrar ✓ (OK)

### Teste 3: Via cURL (Terminal)

```bash
- [ ] curl http://localhost/gerador-mesario/teste_conexao.php
```

Resultado esperado:
- JSON com status "sucesso"

---

## 🎯 FASE 5: TESTE FUNCIONAL COMPLETO

### Gerar e Salvar Voluntário

- [ ] Acessar: `http://localhost/gerador-mesario/index.html`
- [ ] Clicar em "Gerar voluntário"
- [ ] Verificar se os dados aparecem
- [ ] Clicar em "Salvar no banco"
- [ ] Procurar pela mensagem de sucesso

### Listar Voluntários

- [ ] Acessar: `http://localhost/gerador-mesario/listar.php`
- [ ] Verificar se o novo voluntário aparece

Resultado esperado:
```json
{
  "sucesso": true,
  "total": 3,
  "dados": [...]
}
```

---

## 🔧 CONFIGURAÇÕES (se necessário ajustar)

### Arquivo: config.php

Se a conexão não funcionar, verificar:

```php
define('DB_HOST', 'localhost');      // Seu servidor MySQL
define('DB_USER', 'root');           // Seu usuário MySQL
define('DB_PASSWORD', '');           // Sua senha MySQL
define('DB_NAME', 'gerador_mesario');// Nome do banco
```

**Comum:**
- Windows XAMPP: usuário `root`, sem senha
- Linux: usuário `root`, pode pedir senha
- Mac: usuário `root`, pode pedir senha

### MySQLi Não Carregado

Se erro: "Extensão MySQLi não está instalada"

**Windows XAMPP:**
1. Abrir `C:\xampp\php\php.ini`
2. Procurar: `;extension=mysqli`
3. Remover o `;` no início
4. Salvar e reiniciar Apache

**Linux:**
```bash
- [ ] sudo apt-get install php-mysql
- [ ] sudo systemctl restart apache2
```

---

## ❌ TROUBLESHOOTING RÁPIDO

### "Falha ao conectar ao banco de dados"
- [ ] MySQL está rodando?
- [ ] Credenciais em config.php estão corretas?
- [ ] MySQLi extension está carregado?

### "Banco 'gerador_mesario' não foi encontrado"
- [ ] Script SQL foi executado?
- [ ] Nenhum erro ao executar?

### Erro 500 ao salvar
- [ ] Todos os arquivos .php estão na pasta?
- [ ] Pasta tem permissões de escrita?
- [ ] Verificar error_log do Apache

### CPF apareça como "Carregando..." eternamente
- [ ] JavaScript está sendo carregado?
- [ ] Console do navegador mostra erros?

---

## 📊 RESUMO DOS ENDPOINTS

| Endpoint | Método | Descrição |
|----------|--------|-----------|
| `/index.html` | GET | Página principal |
| `/teste_conexao.php` | GET | Teste de conexão |
| `/salvar.php` | POST | Salvar novo voluntário |
| `/listar.php` | GET | Listar todos voluntários |
| `/testes.html` | GET | Página de testes interativa |

---

## 🎬 FLUXO COMPLETO

```
1. Abrir http://localhost/gerador-mesario/index.html
2. Clicar em "Gerar voluntário"
3. Dados aparecem (nome, CPF, data, zona, seção)
4. Clicar em "Salvar no banco"
5. Mensagem de sucesso aparece
6. Acessar http://localhost/gerador-mesario/listar.php
7. Novo voluntário deve aparecer na lista
```

---

## ✨ TUDO PRONTO!

Se todos os itens foram marcados ✓ e os testes passaram:

🎉 **Seu banco de dados está 100% operacional!**

Você pode agora:
- Gerar quantos voluntários quiser
- Salvar no banco automaticamente
- Listar todos os registros
- Exportar dados (futura implementação)

---

## 📞 DÚVIDAS?

1. Revisar o arquivo `README.md` (documentação completa)
2. Acessar `/teste_conexao.php` (diagnóstico automático)
3. Acessar `/testes.html` (testes interativos)
4. Verificar logs do Apache e MySQL

---

**Última atualização:** 2024  
**Status:** ✅ Pronto para produção
