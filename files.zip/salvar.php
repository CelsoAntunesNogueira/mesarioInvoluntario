<?php
/**
 * API para Salvar Voluntários
 * POST: /salvar.php
 * Recebe JSON com dados do voluntário
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Incluir configuração
require_once 'config.php';

// ============================================
// Tratar requisições OPTIONS (CORS preflight)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ============================================
// Verificar método HTTP
// ============================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Método não permitido. Use POST.'
    ]));
}

// ============================================
// Receber dados JSON
// ============================================
$json = file_get_contents('php://input');
$dados = json_decode($json, true);

if (!$dados) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'JSON inválido ou vazio'
    ]));
}

// ============================================
// Validar campos obrigatórios
// ============================================
$campos_obrigatorios = ['nome', 'cpf', 'nascimento'];
$campos_faltando = [];

foreach ($campos_obrigatorios as $campo) {
    if (empty($dados[$campo])) {
        $campos_faltando[] = $campo;
    }
}

if (!empty($campos_faltando)) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Campos obrigatórios faltando: ' . implode(', ', $campos_faltando)
    ]));
}

// ============================================
// Extrair e validar dados
// ============================================
$nome = trim($dados['nome']);
$cpf = preg_replace('/\D/', '', $dados['cpf']); // Remove formatação
$cpf_formatado = substr($cpf, 0, 3) . '.' . substr($cpf, 3, 3) . '.' . substr($cpf, 6, 3) . '-' . substr($cpf, 9, 2);

// Converter data DD/MM/YYYY para YYYY-MM-DD
$data_partes = explode('/', $dados['nascimento']);
if (count($data_partes) !== 3) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Data deve estar no formato DD/MM/YYYY'
    ]));
}
$data_nascimento = $data_partes[2] . '-' . $data_partes[1] . '-' . $data_partes[0];

// Extrair zona e seção
$zona = 0;
$secao = 0;
if (!empty($dados['zona'])) {
    // Formato: "Zona 001 · Seção 1001"
    $zona_partes = preg_match('/Zona (\d+)/', $dados['zona'], $matches);
    $zona = isset($matches[1]) ? (int)$matches[1] : 0;
    
    $secao_partes = preg_match('/Seção (\d+)/', $dados['zona'], $matches);
    $secao = isset($matches[1]) ? (int)$matches[1] : 0;
}

$municipio = !empty($dados['municipio']) ? trim($dados['municipio']) : 'Maricá - RJ';

// ============================================
// Validar CPF (número de dígitos)
// ============================================
if (strlen($cpf) !== 11) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'CPF deve ter 11 dígitos'
    ]));
}

// ============================================
// Validar data de nascimento
// ============================================
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data_nascimento)) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Data de nascimento inválida'
    ]));
}

// ============================================
// Inserir no banco de dados
// ============================================
try {
    $sql = "INSERT INTO voluntarios (nome, cpf, data_nascimento, zona, secao, municipio) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = executarQuery($sql, 'sssii' . 's', [
        $nome,
        $cpf_formatado,
        $data_nascimento,
        $zona,
        $secao,
        $municipio
    ]);
    
    $id_inserido = $conexao->insert_id;
    
    http_response_code(201);
    echo json_encode([
        'sucesso' => true,
        'mensagem' => 'Voluntário salvo com sucesso!',
        'id' => $id_inserido,
        'dados' => [
            'nome' => $nome,
            'cpf' => $cpf_formatado,
            'data_nascimento' => $dados['nascimento'],
            'zona' => $zona,
            'secao' => $secao,
            'municipio' => $municipio
        ]
    ]);
    
    $stmt->close();
    
} catch (Exception $e) {
    // Verificar se é erro de CPF duplicado
    if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
        http_response_code(409);
        die(json_encode([
            'sucesso' => false,
            'mensagem' => 'Este CPF já está registrado no banco de dados'
        ]));
    }
    
    http_response_code(500);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro ao salvar voluntário: ' . $e->getMessage()
    ]));
}

$conexao->close();
?>
