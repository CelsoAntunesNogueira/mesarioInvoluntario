<?php
/**
 * Configuração de Conexão ao Banco de Dados
 * Gerador de Mesário - MySQL
 */

// ============================================
// CONFIGURAÇÕES DO BANCO DE DADOS
// ============================================
define('DB_HOST', 'localhost');      // Servidor MySQL
define('DB_USER', 'root');           // Usuário MySQL
define('DB_PASSWORD', '');           // Senha MySQL (vazio para padrão local)
define('DB_NAME', 'gerador_mesario');// Nome do banco

// ============================================
// CONEXÃO COM TRATAMENTO DE ERRO
// ============================================
try {
    $conexao = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    
    // Verificar erro de conexão
    if ($conexao->connect_error) {
        throw new Exception("Erro de conexão: " . $conexao->connect_error);
    }
    
    // Configurar charset UTF-8
    $conexao->set_charset("utf8mb4");
    
} catch (Exception $e) {
    http_response_code(500);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Falha ao conectar ao banco de dados: ' . $e->getMessage()
    ]));
}

// ============================================
// FUNÇÃO AUXILIAR: Executar Query Segura
// ============================================
function executarQuery($sql, $tipos = "", $parametros = []) {
    global $conexao;
    
    $stmt = $conexao->prepare($sql);
    
    if (!$stmt) {
        throw new Exception("Erro ao preparar statement: " . $conexao->error);
    }
    
    // Se há parâmetros, fazer bind
    if (!empty($parametros)) {
        $stmt->bind_param($tipos, ...$parametros);
    }
    
    if (!$stmt->execute()) {
        throw new Exception("Erro ao executar query: " . $stmt->error);
    }
    
    return $stmt;
}

?>
