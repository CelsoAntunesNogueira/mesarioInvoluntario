<?php
/**
 * TESTE DE CONEXÃO - Gerador de Mesário
 * Acesse: http://localhost/teste_conexao.php
 */

header('Content-Type: application/json; charset=utf-8');

$resultado = [
    'status' => 'erro',
    'testes' => [],
    'resumo' => ''
];

// ============================================
// TESTE 1: Verificar PHP
// ============================================
$resultado['testes'][] = [
    'teste' => '1. Versão do PHP',
    'status' => 'ok',
    'detalhes' => phpversion()
];

// ============================================
// TESTE 2: Extensão MySQLi
// ============================================
if (extension_loaded('mysqli')) {
    $resultado['testes'][] = [
        'teste' => '2. Extensão MySQLi',
        'status' => 'ok',
        'detalhes' => 'MySQLi carregado corretamente'
    ];
} else {
    $resultado['testes'][] = [
        'teste' => '2. Extensão MySQLi',
        'status' => 'erro',
        'detalhes' => 'Extensão MySQLi não está instalada'
    ];
}

// ============================================
// TESTE 3: Conexão ao MySQL
// ============================================
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';

$conexao = @mysqli_connect($db_host, $db_user, $db_password);

if ($conexao) {
    $resultado['testes'][] = [
        'teste' => '3. Conexão ao MySQL',
        'status' => 'ok',
        'detalhes' => 'Conectado ao servidor MySQL (' . $db_host . ')'
    ];
    
    // ============================================
    // TESTE 4: Banco de Dados Existe
    // ============================================
    $db_name = 'gerador_mesario';
    $db_select = @mysqli_select_db($conexao, $db_name);
    
    if ($db_select) {
        $resultado['testes'][] = [
            'teste' => '4. Banco de Dados Existe',
            'status' => 'ok',
            'detalhes' => "Banco '$db_name' encontrado"
        ];
        
        // ============================================
        // TESTE 5: Tabela Voluntários
        // ============================================
        $query = "SHOW TABLES LIKE 'voluntarios'";
        $result = mysqli_query($conexao, $query);
        
        if (mysqli_num_rows($result) > 0) {
            $resultado['testes'][] = [
                'teste' => '5. Tabela Voluntários',
                'status' => 'ok',
                'detalhes' => 'Tabela voluntarios existe'
            ];
            
            // ============================================
            // TESTE 6: Estrutura da Tabela
            // ============================================
            $query = "DESCRIBE voluntarios";
            $result = mysqli_query($conexao, $query);
            $colunas = [];
            
            while ($row = mysqli_fetch_assoc($result)) {
                $colunas[] = $row['Field'];
            }
            
            $colunas_esperadas = ['id', 'nome', 'cpf', 'data_nascimento', 'zona', 'secao', 'municipio', 'criado_em', 'atualizado_em'];
            $colunas_faltando = array_diff($colunas_esperadas, $colunas);
            
            if (empty($colunas_faltando)) {
                $resultado['testes'][] = [
                    'teste' => '6. Estrutura da Tabela',
                    'status' => 'ok',
                    'detalhes' => 'Colunas: ' . implode(', ', $colunas)
                ];
            } else {
                $resultado['testes'][] = [
                    'teste' => '6. Estrutura da Tabela',
                    'status' => 'aviso',
                    'detalhes' => 'Colunas faltando: ' . implode(', ', $colunas_faltando)
                ];
            }
            
            // ============================================
            // TESTE 7: Registros na Tabela
            // ============================================
            $query = "SELECT COUNT(*) as total FROM voluntarios";
            $result = mysqli_query($conexao, $query);
            $row = mysqli_fetch_assoc($result);
            $total = $row['total'];
            
            $resultado['testes'][] = [
                'teste' => '7. Registros na Tabela',
                'status' => 'ok',
                'detalhes' => "Total de registros: $total"
            ];
            
        } else {
            $resultado['testes'][] = [
                'teste' => '5. Tabela Voluntários',
                'status' => 'erro',
                'detalhes' => 'Tabela voluntarios NÃO foi encontrada'
            ];
        }
        
    } else {
        $resultado['testes'][] = [
            'teste' => '4. Banco de Dados Existe',
            'status' => 'erro',
            'detalhes' => "Banco '$db_name' não foi encontrado: " . mysqli_error($conexao)
        ];
    }
    
    mysqli_close($conexao);
    
} else {
    $resultado['testes'][] = [
        'teste' => '3. Conexão ao MySQL',
        'status' => 'erro',
        'detalhes' => 'Não foi possível conectar ao MySQL: ' . mysqli_connect_error()
    ];
}

// ============================================
// RESUMO FINAL
// ============================================
$erros = count(array_filter($resultado['testes'], function($t) { return $t['status'] === 'erro'; }));
$avisos = count(array_filter($resultado['testes'], function($t) { return $t['status'] === 'aviso'; }));

if ($erros === 0) {
    $resultado['status'] = 'sucesso';
    $resultado['resumo'] = $avisos > 0 
        ? "Tudo OK! Mas com $avisos aviso(s)" 
        : "✅ Tudo OK! Banco de dados pronto para usar";
} else {
    $resultado['status'] = 'erro';
    $resultado['resumo'] = "❌ $erros erro(s) encontrado(s)";
}

// ============================================
// RETORNAR JSON
// ============================================
echo json_encode($resultado, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>
