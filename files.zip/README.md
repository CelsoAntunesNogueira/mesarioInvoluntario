# Gerador de Mesário - Documentação do Banco de Dados

## 📋 Índice
1. [Requisitos](#requisitos)
2. [Instalação do Banco de Dados](#instalação-do-banco-de-dados)
3. [Estrutura de Arquivos](#estrutura-de-arquivos)
4. [Teste de Conexão](#teste-de-conexão)
5. [Usando a API](#usando-a-api)
6. [Troubleshooting](#troubleshooting)

---

## ✅ Requisitos

- **MySQL Server 5.7+** (ou MariaDB)
- **PHP 7.4+** com extensão MySQLi
- **Apache** ou outro servidor web
- **localhost** configurado

### Verificar Versões

```bash
# MySQL
mysql --version

# PHP
php --version

# Verificar MySQLi no PHP
php -m | grep mysqli
```

---

## 🚀 Instalação do Banco de Dados

### Passo 1: Abrir MySQL Cliente

**Windows (Command Prompt):**
```cmd
mysql -u root -p
```

**Linux/Mac (Terminal):**
```bash
sudo mysql -u root -p
```

> Se não tiver senha, apenas pressione **Enter**

### Passo 2: Copiar e Executar o Script SQL

Copie todo o conteúdo do arquivo **`database.sql`** e cole no MySQL:

```sql
CREATE DATABASE IF NOT EXISTS gerador_mesario;
USE gerador_mesario;

CREATE TABLE IF NOT EXISTS voluntarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  cpf VARCHAR(14) NOT NULL UNIQUE,
  data_nascimento DATE NOT NULL,
  zona INT NOT NULL,
  secao INT NOT NULL,
  municipio VARCHAR(100) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_cpf (cpf),
  INDEX idx_zona_secao (zona, secao)
);

INSERT INTO voluntarios (nome, cpf, data_nascimento, zona, secao, municipio)
VALUES 
  ('João Silva Santos', '123.456.789-10', '1985-05-15', 1, 1001, 'Maricá - RJ'),
  ('Maria Oliveira Costa', '987.654.321-99', '1990-08-22', 2, 1002, 'Maricá - RJ');
```

Pressione **Enter** e procure por mensagens de sucesso:
```
Query OK, 1 row affected (0.00 sec)
```

### Passo 3: Verificar Instalação

```sql
USE gerador_mesario;
SHOW TABLES;
DESCRIBE voluntarios;
SELECT * FROM voluntarios;
```

---

## 📁 Estrutura de Arquivos

```
projeto-mesario/
├── index.html              # HTML principal (seu arquivo)
├── style.css               # CSS (seu arquivo)
├── script.js               # JavaScript (seu arquivo)
├── config.php              # ✅ Configuração do banco
├── salvar.php              # ✅ API para salvar voluntários
├── listar.php              # ✅ API para listar voluntários
├── teste_conexao.php       # ✅ Teste de conexão
├── database.sql            # ✅ Script SQL
└── README.md               # Documentação (este arquivo)
```

**Coloque todos os arquivos `.php` na mesma pasta que o `index.html`**

---

## 🧪 Teste de Conexão

### Passo 1: Colocar Arquivos PHP no Servidor Web

**Windows (XAMPP):**
- Coloque na pasta `C:\xampp\htdocs\gerador-mesario\`

**Linux (Apache):**
- Coloque na pasta `/var/www/html/gerador-mesario/`

**Mac (MAMP):**
- Coloque na pasta `/Applications/MAMP/htdocs/gerador-mesario/`

### Passo 2: Iniciar Servidor

**XAMPP/WAMP:** Clique em "Start Apache e MySQL"

**Terminal (PHP nativo):**
```bash
cd /caminho/do/projeto
php -S localhost:8000
```

### Passo 3: Acessar Página de Teste

Abra seu navegador e acesse:

```
http://localhost/gerador-mesario/teste_conexao.php
```

ou se usar PHP nativo:

```
http://localhost:8000/teste_conexao.php
```

### Passo 4: Interpretar Resultado

Você verá algo assim:

```json
{
  "status": "sucesso",
  "resumo": "✅ Tudo OK! Banco de dados pronto para usar",
  "testes": [
    {
      "teste": "1. Versão do PHP",
      "status": "ok",
      "detalhes": "8.1.0"
    },
    {
      "teste": "2. Extensão MySQLi",
      "status": "ok",
      "detalhes": "MySQLi carregado corretamente"
    },
    {
      "teste": "3. Conexão ao MySQL",
      "status": "ok",
      "detalhes": "Conectado ao servidor MySQL (localhost)"
    },
    {
      "teste": "4. Banco de Dados Existe",
      "status": "ok",
      "detalhes": "Banco 'gerador_mesario' encontrado"
    },
    {
      "teste": "5. Tabela Voluntários",
      "status": "ok",
      "detalhes": "Tabela voluntarios existe"
    },
    {
      "teste": "6. Estrutura da Tabela",
      "status": "ok",
      "detalhes": "Colunas: id, nome, cpf, data_nascimento, zona, secao, municipio, criado_em, atualizado_em"
    },
    {
      "teste": "7. Registros na Tabela",
      "status": "ok",
      "detalhes": "Total de registros: 2"
    }
  ]
}
```

✅ **Se tudo estiver OK**, você está pronto para usar!

---

## 🔌 Usando a API

### 1. Salvar um Voluntário

**Endpoint:** `POST /salvar.php`

**Dados enviados (JSON):**
```json
{
  "nome": "João Silva Santos",
  "cpf": "123.456.789-10",
  "nascimento": "15/05/1985",
  "zona": "Zona 001 · Seção 1001",
  "municipio": "Maricá - RJ"
}
```

**Resposta (Sucesso):**
```json
{
  "sucesso": true,
  "mensagem": "Voluntário salvo com sucesso!",
  "id": 3,
  "dados": {
    "nome": "João Silva Santos",
    "cpf": "123.456.789-10",
    "data_nascimento": "15/05/1985",
    "zona": 1,
    "secao": 1001,
    "municipio": "Maricá - RJ"
  }
}
```

**Resposta (CPF duplicado):**
```json
{
  "sucesso": false,
  "mensagem": "Este CPF já está registrado no banco de dados"
}
```

### 2. Listar Todos os Voluntários

**Endpoint:** `GET /listar.php`

**Resposta:**
```json
{
  "sucesso": true,
  "total": 2,
  "dados": [
    {
      "id": 1,
      "nome": "João Silva Santos",
      "cpf": "123.456.789-10",
      "data_nascimento": "1985-05-15",
      "zona": 1,
      "secao": 1001,
      "municipio": "Maricá - RJ",
      "criado_em": "2024-01-15 10:30:45"
    }
  ]
}
```

---

## 🔧 Troubleshooting

### ❌ Erro: "Falha ao conectar ao banco de dados"

**Solução 1:** Verificar se MySQL está rodando
```bash
# Linux
sudo systemctl status mysql

# Windows - Abrir Services.msc e procurar por MySQL
```

**Solução 2:** Verificar credenciais em `config.php`
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Seu usuário
define('DB_PASSWORD', '');        // Sua senha
define('DB_NAME', 'gerador_mesario');
```

---

### ❌ Erro: "Banco 'gerador_mesario' não foi encontrado"

**Solução:** Executar o script SQL novamente
```sql
CREATE DATABASE IF NOT EXISTS gerador_mesario;
USE gerador_mesario;
-- ... resto do script
```

---

### ❌ Erro: "Extensão MySQLi não está instalada"

**Windows (XAMPP):**
1. Abra `php.ini` (na pasta de instalação do XAMPP)
2. Procure por `;extension=mysqli`
3. Remova o `;` no início
4. Salve e reinicie Apache

**Linux:**
```bash
sudo apt-get install php-mysql
sudo systemctl restart apache2
```

---

### ❌ Erro 500 ao salvar voluntário

**Verificar:**
1. Arquivo `config.php` existe?
2. Banco de dados foi criado?
3. Extensão MySQLi está ativa?
4. Permissões de pasta estão OK?

**Debug:** Adicione ao `salvar.php`:
```php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

---

## 📊 Estrutura da Tabela

```
Tabela: voluntarios

╔════╦════════════════╦═══════════════════════════╗
║ ID ║ NOME           ║ CPF                       ║
╠════╬════════════════╬═══════════════════════════╣
║ 1  ║ João Silva     ║ 123.456.789-10            ║
║ 2  ║ Maria Oliveira ║ 987.654.321-99            ║
╚════╩════════════════╩═══════════════════════════╝

Colunas:
- id               : INT (PRIMARY KEY, AUTO_INCREMENT)
- nome             : VARCHAR(255)
- cpf              : VARCHAR(14) UNIQUE
- data_nascimento  : DATE
- zona             : INT
- secao            : INT
- municipio        : VARCHAR(100)
- criado_em        : TIMESTAMP
- atualizado_em    : TIMESTAMP
```

---

## 🎯 Fluxo Completo

1. **Gerar Voluntário** → Clique em "Gerar voluntário" no HTML
2. **Dados aparecem** → Nome, CPF, Data, Zona, Seção
3. **Salvar no Banco** → Clique em "Salvar no banco"
4. **API recebe** → `salvar.php` processa e insere
5. **Confirmação** → Mensagem de sucesso aparece
6. **Verificar** → Acesse `listar.php` para ver registros

---

## 📞 Contato

Se tiver dúvidas, verifique:
- ✅ Teste de conexão: `teste_conexao.php`
- ✅ Logs de erro do PHP
- ✅ Credenciais do MySQL em `config.php`
- ✅ Firewall/permissões do SO

---

**Versão:** 1.0  
**Última atualização:** 2024  
**Autor:** Gerador de Mesário
