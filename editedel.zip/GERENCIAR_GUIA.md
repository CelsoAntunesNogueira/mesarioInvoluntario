# 📝 GERENCIAR VOLUNTÁRIOS - Guia de Uso

## 🎯 O que é a página de Gerenciamento?

É uma página completa para **listar, editar e deletar** voluntários já cadastrados no banco de dados.

---

## 🚀 Como Acessar

```
http://localhost/gerador-mesario/gerenciar.html
```

---

## 📋 Funcionalidades

### 1. **Listar Voluntários**
- Mostra tabela com todos os voluntários cadastrados
- Coluna: ID, Nome, CPF, Data Nasc., Zona, Seção
- Atualiza automaticamente ao carregar a página

### 2. **Editar Voluntário**
- Clique no botão **"✎ Editar"** em qualquer linha
- Um modal abre com os dados do voluntário
- Você pode editar: Nome, Data de Nascimento, Zona, Seção, Município
- **CPF não pode ser alterado** (é a chave única)
- Clique em "Salvar Alterações" para confirmar

### 3. **Deletar Voluntário**
- Clique no botão **"🗑 Deletar"** em qualquer linha
- Um modal de confirmação aparece
- Revise o nome do voluntário
- Clique em "Deletar" para confirmar (irreversível!)
- Ou "Cancelar" para manter

### 4. **Adicionar Novo Voluntário**
- Clique em **"+ Novo Voluntário"** no topo da página
- Preencha os campos (nome, CPF, data, zona, seção)
- Clique em "Salvar Alterações"
- Novo registro é adicionado à tabela

---

## 🔌 APIs Utilizadas

### 1. **Listar** (GET)
```php
GET /listar.php

Retorna todos os voluntários com todos os dados
```

### 2. **Editar** (PUT)
```php
PUT /editar.php
Content-Type: application/json

{
  "id": 1,
  "nome": "João Silva Editado",
  "nascimento": "15/05/1988",
  "zona": 5,
  "secao": 2001,
  "municipio": "Maricá - RJ"
}

Retorna: {"sucesso": true, "mensagem": "...", "dados": {...}}
```

### 3. **Deletar** (DELETE)
```php
DELETE /deletar.php
Content-Type: application/json

{
  "id": 1
}

Retorna: {"sucesso": true, "mensagem": "...", "nome": "João Silva"}
```

---

## 🎨 Interface

### Modal de Edição
- Campo de nome editável
- Campo de CPF desabilitado (não pode editar)
- Campo de data (formato: YYYY-MM-DD)
- Campos de zona e seção (números)
- Campo de município (texto)

### Alertas
- **Verde:** Sucesso (voluntário editado/deletado/adicionado)
- **Vermelho:** Erro (dados inválidos, voluntário não encontrado, etc)

### Tabela
- Linhas alternam cor ao passar mouse
- Botões de ação em cada linha
- Modo responsivo em celular/tablet

---

## 🔒 Validações

### No Frontend (JavaScript)
- Verifica campos obrigatórios
- Valida formato de data

### No Backend (PHP)
- Verifica se voluntário existe
- Valida formato de data (DD/MM/YYYY)
- Valida IDs numéricos
- Tratamento de erros completo

---

## 🆘 Troubleshooting

### "Erro ao carregar voluntários"
**Solução:**
- Verificar se `listar.php` existe
- Verificar se MySQL está rodando
- Abrir console (F12) para ver mensagem de erro completa

### "Voluntário não encontrado"
**Solução:**
- Página talvez tenha sido recarregada e lista desatualizada
- Clique F5 para recarregar
- Tente novamente

### "Erro ao editar"
**Solução:**
- Verificar se os dados estão preenchidos corretamente
- Verificar formato da data (DD/MM/YYYY)
- Zona e Seção devem ser números

### Não consegue deletar
**Solução:**
- Certifique-se de que clicou em "Deletar" na confirmação
- Verifique se o voluntário existe
- Recarregue a página (F5)

---

## 📱 Responsivo

A página funciona em:
- ✅ Desktop (1920px+)
- ✅ Tablet (768px+)
- ✅ Celular (320px+)

Tabelafica scrollável em telas pequenas.

---

## 🎨 Tema Escuro/Claro

Clique no botão **🌙** no canto superior direito para:
- Trocar entre tema claro e escuro
- Preferência é salva enquanto estiver na página

---

## ⚙️ Configurações

Nenhuma configuração necessária!

A página lê de `listar.php` e envia para `editar.php` e `deletar.php`.

---

## 📊 Fluxo de Edição

```
Clica "Editar" 
     ↓
Modal abre com dados
     ↓
Edita campos
     ↓
Clica "Salvar Alterações"
     ↓
JavaScript valida
     ↓
Envia PUT para /editar.php
     ↓
PHP valida e atualiza banco
     ↓
Retorna sucesso
     ↓
Modal fecha
     ↓
Tabela recarrega
     ↓
Dados atualizados aparecem
```

---

## 📊 Fluxo de Exclusão

```
Clica "Deletar"
     ↓
Modal de confirmação abre
     ↓
Mostra nome do voluntário
     ↓
Clica "Deletar"
     ↓
JavaScript confirma
     ↓
Envia DELETE para /deletar.php
     ↓
PHP busca e deleta
     ↓
Retorna sucesso
     ↓
Modal fecha
     ↓
Tabela recarrega
     ↓
Voluntário desaparece
```

---

## 🔐 Segurança

- ✅ Validação em ambos os lados (frontend + backend)
- ✅ Prepared Statements (sem SQL Injection)
- ✅ Confirmação antes de deletar
- ✅ CPF não pode ser alterado (evita duplicatas)
- ✅ CORS headers implementado
- ✅ HTTP Status Codes corretos

---

## 💡 Dicas

1. **Sempre confirme antes de deletar** - Não há desfazer!
2. **CPF não pode ser alterado** - É a chave única do sistema
3. **Recarregue se algo estranho acontecer** - Clique F5
4. **Use o console (F12) para ver erros** - Ajuda no troubleshooting
5. **Mantenha backup do banco** - Use `mysqldump` regularmente

---

## 🎯 Próximos Passos (Melhorias Futuras)

- [ ] Adicionar filtros de busca
- [ ] Adicionar ordenação de colunas
- [ ] Adicionar paginação (para muitos registros)
- [ ] Exportar para CSV/Excel
- [ ] Importar de CSV/Excel
- [ ] Histórico de alterações
- [ ] Permissões de acesso

---

## 📞 Referência Rápida

| Ação | Como fazer |
|------|-----------|
| Ver todos | Página carrega automaticamente |
| Editar | Clique "✎ Editar" + mude dados + "Salvar" |
| Deletar | Clique "🗑 Deletar" + "Deletar" na confirmação |
| Adicionar | Clique "+ Novo Voluntário" + dados + "Salvar" |
| Recarregar | Pressione F5 |
| Tema | Clique 🌙 no canto superior |
| Voltar | Clique browser back ou feche a aba |

---

**Versão:** 1.0  
**Data:** 2024  
**Status:** ✅ Funcional
