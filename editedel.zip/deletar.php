<?php
/**
 * API para Deletar Voluntários
 * DELETE: /deletar.php
 * Recebe JSON com ID do voluntário a ser deletado
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

// ============================================
// Tratar requisições OPTIONS (CORS preflight)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ============================================
// Verificar método HTTP
// ============================================
if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Método não permitido. Use DELETE.'
    ]));
}

// ============================================
// Receber dados JSON
// ============================================
$json = file_get_contents('php://input');
$dados = json_decode($json, true);

if (!$dados || empty($dados['id'])) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'ID do voluntário não fornecido'
    ]));
}

$id = (int)$dados['id'];

if ($id <= 0) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'ID inválido'
    ]));
}

// ============================================
// Verificar se voluntário existe
// ============================================
try {
    $sql = "SELECT nome FROM voluntarios WHERE id = ?";
    $stmt = executarQuery($sql, 'i', [$id]);
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        http_response_code(404);
        die(json_encode([
            'sucesso' => false,
            'mensagem' => 'Voluntário não encontrado'
        ]));
    }
    
    $row = $result->fetch_assoc();
    $nome_voluntario = $row['nome'];
    $stmt->close();
    
    // ============================================
    // Deletar do banco de dados
    // ============================================
    $sql = "DELETE FROM voluntarios WHERE id = ?";
    $stmt = executarQuery($sql, 'i', [$id]);
    
    http_response_code(200);
    echo json_encode([
        'sucesso' => true,
        'mensagem' => 'Voluntário deletado com sucesso!',
        'id' => $id,
        'nome' => $nome_voluntario
    ]);
    
    $stmt->close();
    
} catch (Exception $e) {
    http_response_code(500);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro ao deletar voluntário: ' . $e->getMessage()
    ]));
}

$conexao->close();
?>
