<?php
/**
 * API para Editar Voluntários
 * PUT: /editar.php
 * Recebe JSON com dados atualizados do voluntário
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

// ============================================
// Tratar requisições OPTIONS (CORS preflight)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ============================================
// Verificar método HTTP
// ============================================
if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Método não permitido. Use PUT.'
    ]));
}

// ============================================
// Receber dados JSON
// ============================================
$json = file_get_contents('php://input');
$dados = json_decode($json, true);

if (!$dados) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'JSON inválido ou vazio'
    ]));
}

// ============================================
// Validar campos obrigatórios
// ============================================
$campos_obrigatorios = ['id', 'nome', 'nascimento'];
$campos_faltando = [];

foreach ($campos_obrigatorios as $campo) {
    if (empty($dados[$campo])) {
        $campos_faltando[] = $campo;
    }
}

if (!empty($campos_faltando)) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Campos obrigatórios faltando: ' . implode(', ', $campos_faltando)
    ]));
}

// ============================================
// Extrair e validar dados
// ============================================
$id = (int)$dados['id'];
$nome = trim($dados['nome']);

// Converter data DD/MM/YYYY para YYYY-MM-DD
$data_partes = explode('/', $dados['nascimento']);
if (count($data_partes) !== 3) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Data deve estar no formato DD/MM/YYYY'
    ]));
}
$data_nascimento = $data_partes[2] . '-' . $data_partes[1] . '-' . $data_partes[0];

// Extrair zona e seção
$zona = !empty($dados['zona']) ? (int)$dados['zona'] : 0;
$secao = !empty($dados['secao']) ? (int)$dados['secao'] : 0;
$municipio = !empty($dados['municipio']) ? trim($dados['municipio']) : 'Maricá - RJ';

// ============================================
// Validar data de nascimento
// ============================================
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data_nascimento)) {
    http_response_code(400);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Data de nascimento inválida'
    ]));
}

// ============================================
// Verificar se voluntário existe
// ============================================
try {
    $sql = "SELECT id FROM voluntarios WHERE id = ?";
    $stmt = executarQuery($sql, 'i', [$id]);
    
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        die(json_encode([
            'sucesso' => false,
            'mensagem' => 'Voluntário não encontrado'
        ]));
    }
    
    $stmt->close();
    
    // ============================================
    // Atualizar no banco de dados
    // ============================================
    $sql = "UPDATE voluntarios 
            SET nome = ?, 
                data_nascimento = ?, 
                zona = ?, 
                secao = ?, 
                municipio = ? 
            WHERE id = ?";
    
    $stmt = executarQuery($sql, 'ssiii' . 'i', [
        $nome,
        $data_nascimento,
        $zona,
        $secao,
        $municipio,
        $id
    ]);
    
    http_response_code(200);
    echo json_encode([
        'sucesso' => true,
        'mensagem' => 'Voluntário atualizado com sucesso!',
        'id' => $id,
        'dados' => [
            'nome' => $nome,
            'data_nascimento' => $dados['nascimento'],
            'zona' => $zona,
            'secao' => $secao,
            'municipio' => $municipio
        ]
    ]);
    
    $stmt->close();
    
} catch (Exception $e) {
    http_response_code(500);
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro ao atualizar voluntário: ' . $e->getMessage()
    ]));
}

$conexao->close();
?>
